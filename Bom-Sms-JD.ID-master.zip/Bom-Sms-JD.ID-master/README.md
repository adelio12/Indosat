# Bom-Sms-JD.ID
BOM SMS JD.ID v1

# How to use?
Click 2x "run.bat" or Open CMD "php bom.php"
